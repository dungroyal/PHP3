@extends('layouts._layout')
@section('content')
    <h1>Home Page</h1>
@endsection
