<html>
    <head>
        <title>Ps09033</title>
    </head>
    <body>
        <h1><?php echo $__env->yieldContent('heading'); ?></h1>
        <h2>Welcom!!!!</h2>

        <?php $__env->startSection('blockbody'); ?>
        <?php echo $__env->yieldSection(); ?>
    </body>
</html><?php /**PATH D:\xampp\htdocs\php3\lab1\resources\views/layouts/layout0.blade.php ENDPATH**/ ?>