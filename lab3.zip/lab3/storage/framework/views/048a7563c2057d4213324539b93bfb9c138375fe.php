

<?php $__env->startSection('heading','First page'); ?>

<?php $__env->startSection('blockbody'); ?>
    <p>hãy trao cho anh</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout0', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\php3\lab1\resources\views/hello1.blade.php ENDPATH**/ ?>