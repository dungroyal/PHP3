<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php?ctrller=home">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/product">List product</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/hello0">Hello</a>
        </li>
    </nav>
    <div class="card">
  <div class="card-header">
  <?php echo $pro['productName']?>
  </div>
  <div class="card-body">
    <h3>sản phẩm chi tiết</h3>
    <div class="box">
    <ul>
        <li>Tên sản phẩm:<?php echo $pro['productName']?></li>
        <li>Mã sản phẩm:<?php echo $pro['productCode']?></li>
        <li>Ngày ra mắt:<?php echo $pro['releaseDate']?></li>
        <li>Giá sản phẩm:<?php echo $pro['price']?></li>
        <li>Chi tiết:<?php echo $pro['description']?></li>
        <li>Đánh giá:<?php echo $pro['starRating']?></li>
    </ul>
    </div>
    <div class="box">
    <img src="assets/images/<?php echo $pro['imageUrl']?>" width="400px">
    </div>
  </div>
  </div><?php /**PATH D:\xampp\htdocs\php3\lab1\resources\views/product/productdetail.blade.php ENDPATH**/ ?>