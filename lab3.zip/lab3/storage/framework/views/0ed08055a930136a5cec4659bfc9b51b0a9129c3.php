
<?php $__env->startSection('content'); ?>
<div class="card">
        <div class="card-header">
          List flights
        </div>
        <div class="card-body">
            <table class="table">
            <thead>
                  <tr>
                    <th>Mã chuyến</th>
                    <th>Xuất phát</th>
                    <th>Điểm đến</th>
                    <th>Thời lượng</th>
                    <th>Action</th>
                  </tr>
              </thead>
              <tbody>
           <?php $__currentLoopData = $flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($flight->id); ?></td>
                <td><?php echo e($flight->origin); ?></td>
                <td><?php echo e($flight->destination); ?></td>
                <td><?php echo e($flight->duration); ?></td>
                <td>
                  <a href="#" class="btn btn-primary">Edit</a>
                  <a href="#" class="btn btn-danger">Delete</a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
      </div><!--end card-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\php3\lab3\resources\views/flight.blade.php ENDPATH**/ ?>