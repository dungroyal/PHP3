<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\flight;

class flightController extends Controller
{
    function index()
    {
        $flights=flight::all();//tra ve tat ca tuyen bay
        return view('flight',['flights'=>$flights]);
    }
    function create()
    {
        return view('create');
    }
    function store(Request $request)
    {
        //get data form
        $data=array(
            'origin'=>$request->origin,
            'destination'=>$request->destination,
            'duration'=>$request->duration
        );
        //them vao database
        flight::create($data);
        return redirect('/flight');
    }
}
