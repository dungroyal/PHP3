<div class="card">
  <div class="card-header">
    List products
  </div>
  <div class="card-body">
      <div class="row search">
          <div class='col-md-12'>
              <input type='text'/>
              <button>Search</button>
          </div>
          
      </div>
      <table class=" table">
        <thead>
            <tr>
              <th>Image</th>
              <th>Product</th>
              <th>Code</th>
              <th>Available</th>
              <th>Price </th>
              <th>5 Star Rating</th>
            </tr>
        </thead>
        <tbody>
        <tr>
              <td>
                <img src='assets/images/hammer.png' width="50px">
              </td>
              <td><a href="index.php?ctrller=products">Hammer</a> </td>
              <td>GDN-123</td>
              <td>20-12-2019</td>
              <td>$200</td>
              <td>3.4</td>
            </tr>
            <tr>
              <td>
                <img src='assets/images/saw.jpg' width="50px">
              </td>
              <td><a href="index.php?ctrller=products">Saw</a> </td>
              <td>GDN-123</td>
              <td>20-12-2019</td>
              <td>$200</td>
              <td>3.4</td>
            </tr>
        </tbody>
    </table>

   
  </div>
</div>